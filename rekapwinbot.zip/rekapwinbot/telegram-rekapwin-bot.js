import TelegramBot from "node-telegram-bot-api";
import fs from "fs";
import dotenv from "dotenv";

dotenv.config();
const token = process.env.BOT_TOKEN;
if (!token) {
  console.error("❌ BOT_TOKEN tidak ditemukan di .env atau Railway Variables!");
  process.exit(1);
}

const bot = new TelegramBot(token, { polling: true });
const saldoFile = "./data/saldo.json";

if (!fs.existsSync("./data")) fs.mkdirSync("./data");
if (!fs.existsSync(saldoFile)) fs.writeFileSync(saldoFile, "{}");

function getSaldo() {
  return JSON.parse(fs.readFileSync(saldoFile));
}
function saveSaldo(data) {
  fs.writeFileSync(saldoFile, JSON.stringify(data, null, 2));
}

// 💬 Command handler
bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id, "👋 Halo! Ini adalah bot *RekapRyve*.\nGunakan /rekapwin untuk mulai rekap duel.", { parse_mode: "Markdown" });
});

bot.onText(/\/rekapwin(?: (.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const feeInput = match[1] ? match[1].trim() : "5.5";
  let mode = "NORMAL";
  let fee = 5.5;

  if (feeInput.toLowerCase() === "nc") {
    mode = "NO CUT";
  } else if (!isNaN(parseFloat(feeInput))) {
    fee = parseFloat(feeInput);
  }

  bot.sendMessage(chatId, `📊 Mode perhitungan: *${mode}* (Fee: ${fee}%)\n\nSilakan balas pesan data duel dengan format:\n\nKECIL: ...\nBESAR: ...`, { parse_mode: "Markdown" });
});

bot.onText(/\/tambah (.+) (\d+)/, (msg, match) => {
  const [_, nama, jumlah] = match;
  const data = getSaldo();
  data[nama.toUpperCase()] = (data[nama.toUpperCase()] || 0) + parseInt(jumlah);
  saveSaldo(data);
  bot.sendMessage(msg.chat.id, `💰 Saldo ${nama} ditambah ${jumlah}. Total: ${data[nama.toUpperCase()]}`);
});

bot.onText(/\/kurangi (.+) (\d+)/, (msg, match) => {
  const [_, nama, jumlah] = match;
  const data = getSaldo();
  data[nama.toUpperCase()] = (data[nama.toUpperCase()] || 0) - parseInt(jumlah);
  saveSaldo(data);
  bot.sendMessage(msg.chat.id, `📉 Saldo ${nama} dikurangi ${jumlah}. Total: ${data[nama.toUpperCase()]}`);
});

bot.onText(/\/wd (.+)/, (msg, match) => {
  const nama = match[1].toUpperCase();
  const data = getSaldo();
  const saldo = data[nama] || 0;
  bot.sendMessage(msg.chat.id, `🏦 Saldo ${nama}: ${saldo}`);
});

bot.onText(/\/resetlw/, (msg) => {
  saveSaldo({});
  bot.sendMessage(msg.chat.id, "🔄 History saldo berhasil direset.");
});

bot.on("polling_error", console.error);
console.log("✅ RekapRyve Bot aktif dan polling Telegram API...");