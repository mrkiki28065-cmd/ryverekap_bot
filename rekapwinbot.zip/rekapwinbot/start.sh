#!/bin/bash
echo "🚀 Starting RekapRyve Bot..."
node telegram-rekapwin-bot.js