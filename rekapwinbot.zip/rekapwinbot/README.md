# 🤖 RekapRyve Bot

Bot Telegram untuk rekap duel dan saldo otomatis (Mode Normal & No Cut).

### 🚀 Cara Menjalankan (Railway)

1. Upload semua file ke GitHub (jangan dalam bentuk ZIP).
2. Deploy repo ini ke [Railway.app](https://railway.app/).
3. Tambahkan variable:
   - `BOT_TOKEN=token_bot_dari_BotFather`
4. Klik **Deploy**.
5. Bot langsung aktif dan mulai polling pesan.

---

### 💡 Command Utama
- `/rekapwin` — proses data duel
- `/resetlw` — reset history
- `/lunas [nama]` — lunasi saldo
- `/tambah [nama] [jumlah]`
- `/kurangi [nama] [jumlah]`
- `/depo [nama] [jumlah]`
- `/wd [nama]` — cek saldo
- `/bulatkan` — pembulatan saldo
- `/m1only [skor]` — ubah skor match terakhir
- `/edit [tim] [skor]` — ubah hasil duel terakhir

Semua data disimpan otomatis di `data/saldo.json`.